import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from '../models/product';
import { AdminAuthGuard } from '../services/admin-auth-guard.service';
import { AuthGuard } from '../services/auth-guard.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  showProducts: boolean = false;
  productList: Array<Product> = [];
  i: number = 0;
  tot: string;
  search: string;
  loginStatus: boolean = false;
  adminLoginStatus: boolean = false;
  value: string;

  products: Array<Product>;
  constructor(
    private _httpClient: HttpClient,
    private _router: Router,
    private _authguard: AuthGuard,
    private _admin: AdminAuthGuard
  ) {}

  ngOnInit(): void {
    this._httpClient
      .get<Product[]>('http://localhost:5000/products')
      .subscribe((result) => {
        this.products = result;
        console.log(result);
      });
    this.loginStatus = this._authguard.isLoggedIn();
    this.adminLoginStatus = this._admin.isAdminLoggedIn();
  }

  changeStatus() {
    if (this.showProducts == true) {
      this.showProducts = false;
    } else {
      this.showProducts = true;
    }
  }

  addToCart(product) {
    this.i = this.i + 1;

    if (this.productList.includes(product)) {
      product.qty = product.qty + 1;
      product.price = product.qty * product.price;
    } else {
      product.qty = 1;
      this.productList.push(product);
    }
  }
  removeProduct(product) {
    const index = this.productList.indexOf(product);
    if (index > -1) {
      this.i = this.i - 1;
      this.productList.splice(index, 1);
    }
  }
  total() {
    localStorage.setItem(
      'total',
      this.productList
        .reduce((total, product) => total + product.price, 0)
        .toString()
    );
    return this.productList.reduce(
      (total, product) => total + product.price,
      0
    );
  }
  checkout() {
    localStorage.setItem('productList', JSON.stringify(this.productList));

    if (this.productList.length > 0) {
      this._router.navigate(['/checkout']);
    } else {
      alert('please add items to your cart');
    }
  }
}
