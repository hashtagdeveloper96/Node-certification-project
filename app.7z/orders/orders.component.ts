import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Order } from '../models/order';
import { AuthGuard } from '../services/auth-guard.service';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css'],
})
export class OrdersComponent implements OnInit {
  id: string;
  orders: Array<Order>;
  loginStatus: boolean = false;
  constructor(private _httpClient: HttpClient, private _authguard: AuthGuard) {}

  ngOnInit(): void {
    this.id = localStorage.getItem('id');
    this._httpClient
      .get<any>('http://localhost:5000/orders/' + this.id)
      .subscribe(
        (result) => {
          this.orders = result.map((result) => result.orders);
        },
        (error) => {
          console.log(error);
        }
      );
    this.loginStatus = this._authguard.isLoggedIn();
  }
}
