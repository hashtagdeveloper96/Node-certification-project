import { Component, OnInit } from '@angular/core';
import { Product } from '../models/product';
import { AuthGuard } from '../services/auth-guard.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css'],
})
export class OrderComponent implements OnInit {
  productList: Array<Product>;
  address: string;
  status: boolean = true;
  loginStatus: boolean = false;
  constructor(private _authguard: AuthGuard) {}

  ngOnInit(): void {
    if (this.status != null) {
      this.status = JSON.parse(localStorage.getItem('showStatus'));
    }
    console.log(localStorage.getItem('showStatus'));
    this.productList = JSON.parse(localStorage.getItem('productList'));
    this.address = localStorage.getItem('newaddress');
    this.loginStatus = this._authguard.isLoggedIn();
  }
}
