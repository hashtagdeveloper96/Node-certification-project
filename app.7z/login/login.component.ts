import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  user: User = new User();
  users: any = [];
  success: boolean = false;

  constructor(private _httpClient: HttpClient, private _router: Router) {}

  ngOnInit(): void {}

  login() {
    this._httpClient.get('http://localhost:5000/users').subscribe(
      (result) => {
        this.users = result;

        for (let index = 0; index < this.users.length; index++) {
          if (
            this.user.email == this.users[index].email &&
            this.user.password == this.users[index].password
          ) {
            localStorage.setItem('username', this.users[index].fullName);
            localStorage.setItem('email', this.users[index].email);
            localStorage.setItem('id', this.users[index]._id);
            console.log(this.users[index]._id);
            localStorage.setItem('password', this.users[index].password);
            localStorage.setItem(
              'confirmPassword',
              this.users[index].confirmPassword
            );
            localStorage.setItem('address', this.users[index].address);
            localStorage.setItem('card', this.users[index].card);
            localStorage.setItem('orders', this.users[index].orders);
            localStorage.setItem('role', 'user');
            localStorage.setItem(
              'profilePhoto',
              this.users[index].profilePhoto
            );

            localStorage.setItem('isLoggedIn', 'true');

            this.success = true;
            this._router.navigate(['/home']);
          }
        }
        if (this.success == false) {
          alert('Please enter correct details');
        }
      },
      (error) => {
        console.log(error);
      }
    );
  }
}
