import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Admin } from '../models/admin';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css'],
})
export class AdminLoginComponent implements OnInit {
  admin: Admin = new Admin();
  adminuser: any = [];
  success: boolean = false;
  constructor(private _httpClient: HttpClient, private _router: Router) {}

  ngOnInit(): void {}
  login() {
    this._httpClient.get('http://localhost:5000/admin').subscribe(
      (result) => {
        this.adminuser = result;

        for (let index = 0; index < this.adminuser.length; index++) {
          if (
            this.admin.email == this.adminuser[index].email &&
            this.admin.password == this.adminuser[index].password
          ) {
            localStorage.setItem('username', this.adminuser[index].fullName);
            localStorage.setItem('email', this.adminuser[index].email);
            localStorage.setItem('id', this.adminuser[index]._id);
            console.log(this.adminuser[index]._id);
            localStorage.setItem('password', this.adminuser[index].password);
            localStorage.setItem(
              'confirmPassword',
              this.adminuser[index].confirmPassword
            );
            localStorage.setItem('address', this.adminuser[index].address);
            localStorage.setItem('card', this.adminuser[index].card);
            localStorage.setItem('orders', this.adminuser[index].orders);
            localStorage.setItem(
              'profilePhoto',
              this.adminuser[index].profilePhoto
            );
            localStorage.setItem('role', 'admin');

            localStorage.setItem('isAdminLoggedIn', 'true');

            this.success = true;
            this._router.navigate(['/admin-home']);
          }
        }
        if (this.success == false) {
          alert('Please enter correct details');
        }
      },
      (error) => {
        console.log(error);
      }
    );
  }
}
