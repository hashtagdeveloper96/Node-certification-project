export class Admin {
  fullName: string = '';
  email: string = '';
  password: string = '';
  confirmPassword: string = '';
  profilePhoto: File = null;
  address: string = '';
  card: number = null;
}
