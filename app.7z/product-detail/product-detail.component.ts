import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../models/product';
import { AuthGuard } from '../services/auth-guard.service';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css'],
})
export class ProductDetailComponent implements OnInit {
  loginStatus: boolean = false;
  constructor(
    private _httpClient: HttpClient,
    private _route: ActivatedRoute,
    private _router: Router,
    private _authguard: AuthGuard
  ) {}
  id: any;
  product: Product = new Product();
  ngOnInit(): void {
    this.id = this._route.snapshot.paramMap.get('id');
    this._httpClient
      .get<Product>('http://localhost:5000/products/' + this.id)
      .subscribe(
        (result) => {
          console.log(result);
          this.product = result;
        },
        (error) => {
          console.log(error);
        }
      );
    this.loginStatus = this._authguard.isLoggedIn();
  }
}
