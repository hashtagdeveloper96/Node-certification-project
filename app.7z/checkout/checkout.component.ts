import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Order } from '../models/order';

import { Product } from '../models/product';
import { OrderComponent } from '../order/order.component';
import { AuthGuard } from '../services/auth-guard.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css'],
})
export class CheckoutComponent implements OnInit {
  productList: Array<Product>;
  total: string;
  address: string;
  newaddress: string;
  id: string;
  email: string;
  card: string;
  showAddress: boolean = false;
  showAddCard: boolean = false;
  showStatus: boolean = false;
  order: Order = new Order();
  loginStatus: boolean = false;

  constructor(
    private _httpClient: HttpClient,
    private _router: Router,
    private _authguard: AuthGuard
  ) {}

  ngOnInit(): void {
    this.productList = JSON.parse(localStorage.getItem('productList'));
    this.total = localStorage.getItem('total');
    this.id = localStorage.getItem('id');
    this.address = localStorage.getItem('address');
    this.card = localStorage.getItem('card');
    this.email = localStorage.getItem('email');
    this.loginStatus = this._authguard.isLoggedIn();
  }
  show() {
    this.showAddress = true;
  }
  done() {
    this.showAddCard = true;
  }
  placeorder() {
    localStorage.setItem('newaddress', this.address);
    this.order.id = localStorage.getItem('id');
    this.order.email = this.email;
    this.order.orders = this.productList;
    if (
      this.address != '' &&
      this.card != '' &&
      this.card.length == 16 &&
      this.address.length >= 7
    ) {
      this._httpClient
        .post('http://localhost:5000/orders/save', this.order)
        .subscribe((result) => {
          console.log(result);
        });

      this._httpClient
        .patch('http://localhost:5000/users/' + this.id, {
          address: this.address,
          card: parseInt(this.card),
        })
        .subscribe((result) => {
          localStorage.setItem('order', JSON.stringify(result));
          (this.showStatus = true),
            localStorage.setItem('showStatus', String(this.showStatus));
          console.log('Hello');
          this._router.navigate(['/order']);
        });
    } else {
      alert(
        'Please enter valid address and Card details is required and must be 16 characters'
      );
    }
  }
}
