import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { AuthGuard } from '../services/auth-guard.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent implements OnInit {
  user: User = new User();
  id: string;
  showEdit: boolean = false;
  loginStatus: boolean = false;

  constructor(
    private _httpClient: HttpClient,
    private _router: Router,
    private _authguard: AuthGuard
  ) {}

  ngOnInit(): void {
    this.user.fullName = localStorage.getItem('username');
    this.user.email = localStorage.getItem('email');
    this.id = localStorage.getItem('id');
    this.user.password = localStorage.getItem('password');
    this.user.confirmPassword = localStorage.getItem('confirmPassword');
    this.user.address = localStorage.getItem('address');
    this.user.card = parseInt(localStorage.getItem('card'));
    this.loginStatus = this._authguard.isLoggedIn();
  }
  EditEmp() {
    this.showEdit = true;
  }
  update() {
    this.showEdit = false;
    this._httpClient
      .put('http://localhost:5000/users/' + this.id, this.user)
      .subscribe(
        (result) => {
          localStorage.setItem('username', this.user.fullName);
          localStorage.setItem('email', this.user.email);

          localStorage.setItem('password', this.user.password);
          localStorage.setItem('confirmPassword', this.user.confirmPassword);
          localStorage.setItem('address', this.user.address);
          localStorage.setItem('card', this.user.card.toString());

          this._router.navigate(['/home']);
        },
        (error) => {
          console.log(error);
        }
      );
  }
}
