import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../models/user';
import { AdminAuthGuard } from '../services/admin-auth-guard.service';

@Component({
  selector: 'app-manage-users',
  templateUrl: './manage-users.component.html',
  styleUrls: ['./manage-users.component.css'],
})
export class ManageUsersComponent implements OnInit {
  userList: Array<User> = [];
  adminLoginStatus: boolean = false;
  users: Array<User>;
  constructor(
    private _httpClient: HttpClient,
    private _router: Router,
    private _admin: AdminAuthGuard
  ) {}

  ngOnInit(): void {
    this._httpClient
      .get<User[]>('http://localhost:5000/users')
      .subscribe((result) => {
        this.users = result;
      });

    this.adminLoginStatus = this._admin.isAdminLoggedIn();
  }
}
