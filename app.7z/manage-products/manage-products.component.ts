import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from '../models/product';
import { AdminAuthGuard } from '../services/admin-auth-guard.service';

@Component({
  selector: 'app-manage-products',
  templateUrl: './manage-products.component.html',
  styleUrls: ['./manage-products.component.css'],
})
export class ManageProductsComponent implements OnInit {
  productList: Array<Product> = [];
  adminLoginStatus: boolean = false;
  products: Array<Product>;

  constructor(
    private _httpClient: HttpClient,
    private _router: Router,
    private _admin: AdminAuthGuard
  ) {}

  ngOnInit(): void {
    this._httpClient
      .get<Product[]>('http://localhost:5000/products')
      .subscribe((result) => {
        this.products = result;
        console.log(result);
      });

    this.adminLoginStatus = this._admin.isAdminLoggedIn();
  }
}
